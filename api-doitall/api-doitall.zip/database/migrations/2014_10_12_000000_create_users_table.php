<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->tinyInteger('status')->default(1)->comment('0 bloqueado - 1 liberado - 2 pendente');
            $table->tinyInteger('role')->default(0)->comment('0-Paciente - 1-Funcionario - 2-Administrador');
            $table->string('name',50);
            $table->string('phone',50)->default(0);
            $table->string('cpf',11)->default(0);
            $table->string('address')->nullable();
            $table->string('city',60)->nullable();
            $table->string('uf',2)->nullable();
            $table->string('email',150)->unique();
            $table->timestamp('email_verified_at')->nullable();
            $table->string('password');
            $table->uuid('uid')->nullable();
            //
            $table->rememberToken();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
};
