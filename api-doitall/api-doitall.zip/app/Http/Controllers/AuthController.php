<?php

namespace App\Http\Controllers;

use Exception;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    function Register(Request $R){
        try{
            $cred = new User();
            $cred->name = $R->name;
            $cred->email = $R->email;
            $cred->password = Hash::make($R->password);
            $cred->save();
            $response=['status' => 200, 'message' => 'Registrado com sucesso', 'user'=> $cred];
            return response()->json($response);
        }catch(Exception $e){

            $response = ['status'=> 500, 'message'=> $e];
        }
    }
    function Login(Request $R){
        $user = User::where('email', $R->email)->first();
        if(!$user){
            $response = ['status'=> 500, 'message'=> 'Email ou senha incorretos!'];
            return response()->json($response);
        }

        if($user !='[]' && Hash::check($R->password,$user->password)){
            $token = $user->createToken('Personal Acess Token')->plainTextToken;
            $response = ['status'=> 200, 'token'=> $token, 'user'=> $user, 'message'=> 'Login efetuado com sucesso'];
            return response()->json($response);
        }else{

            $response = ['status'=> 500, 'message'=> 'Email ou senha incorretos!'];
            return response()->json($response);
        }
    }

    function List(){
        try{
            $users = User::all();
            $response=['status' => 200, 'users' => $users];
            return response()->json($response);
        }catch(Exception $e){

            $response = ['status'=> 500, 'message'=> $e];
        }
    }
}
